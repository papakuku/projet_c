#include <stdio.h>
#include <string.h>
#include "player.h"






int main(void)
{
	player p1 = create();
	say(p1, "bonjour");


	printf("\nok\n");

	return 0;

}
